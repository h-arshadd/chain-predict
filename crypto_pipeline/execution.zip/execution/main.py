"""
main.py
-------

Entry point of the Execution Module.

Shares its DECISION math with the Simulator Module (imports the pure
sizing/TP-SL/exit-check helpers from simulator.py -- that logic is just
arithmetic, nothing simulator-specific about it) but NOT its fill math.
simulator.py's step_candle() assumes a paper fill at the candle's
open/close price -- that assumption is wrong here. Execution instead:

  1. Uses the same signal + TP/SL + direction-change RULES as the
     simulator to decide WHEN to open/close a position.
  2. When a decision is made, places a REAL market order on Bybit
     (bybit_client.place_market_order) and reads back what it actually
     filled at (avgPrice/cumExecQty/fee from Bybit itself).
  3. Builds the position/ledger entirely from that real fill data -- NOT
     from the candle price the decision was triggered on. This is the
     one place execution genuinely differs from simulator: the ledger
     reflects what really happened on the exchange, not a paper fill.

Nothing pair/strategy-specific is hardcoded or read from a local config
file -- the universe (which (exchange, symbol) pairs to trade, and which
single strategy to run per pair) is entirely DB-driven, same as
simulator: every row in execution.config (see
db_utils.get_execution_universe/get_execution_config/
save_execution_config). The ONLY thing local to this machine is the
Bybit API key/secret, read from .env (BYBIT_API_KEY/BYBIT_API_SECRET/
BYBIT_DEMO) via bybit_client.get_client_from_env() -- secrets never
go in the DB or a checked-in config file.

Meant to be run repeatedly (Task Scheduler -> run_execution.bat), same as
simulator. Each run, per registered (exchange, symbol) pair:
  1. Loads saved state (last processed candle, balance, open position)
     from execution.positions -- or starts fresh on first run.
  2. Pulls recent live 1-minute candles from Bybit directly (only the new
     ones since last_processed).
  3. Resamples to the strategy's time_horizon and generates signals with
     the exact same signal pipeline every other module uses.
  4. Walks forward candle by candle, deciding open/close/hold exactly
     like simulator does, but on a decision to open or close, places the
     real order first and only then records what happened, from the
     order's real fill.
  5. Saves state back to execution.positions, appends any newly-closed
     trades to execution.{exchange}_{symbol}_{strategy}_trades.

Execution settings (initial_balance, position_size, commission, slippage,
allow_long, allow_short, max_open_positions, strategy_name) come
from execution.config (see db_utils.get_execution_config), same pattern
as simulator.config plus strategy_name. commission/slippage in
execution.config are effectively unused for real trades now (the real
fee comes back from Bybit itself on every order) -- kept only because
get_execution_config still returns them. take_profit/stop_loss and the
strategy's indicators/conditions/time_horizon come from metadata.strategy,
same as simulator.
"""

from datetime import datetime

import pandas as pd

from crypto_pipeline.simulator.simulator import _position_size, _tp_sl_prices, _check_exit, _leaning
from crypto_pipeline.signals.main import generate_signals
from crypto_pipeline.execution.bybit_client import get_client_from_env, get_live_ohlcv, place_market_order
from crypto_pipeline.utils.db_utils import (
    get_db_connection,
    get_execution_state,
    save_execution_state,
    append_execution_trades,
    get_execution_summary,
    get_execution_config,
    get_execution_universe,
    build_execution_equity_curve_from_ledger,
    save_execution_stats,
)
from crypto_pipeline.utils.metadata_utils import (
    get_db_connection as get_metadata_connection,
    get_strategies,
)
from crypto_pipeline.stats.calculator import compute_stats

# stats/config.yaml -- same config compute_stats() takes everywhere else,
# loaded the same way simulator/main.py loads it (see that module's
# _load_stats_config() for the reasoning on not reusing stats_runner's
# leading-underscore internal default).
def _load_stats_config():
    import yaml
    from pathlib import Path
    stats_config_path = Path(__file__).parent.parent / "stats" / "config.yaml"
    with open(stats_config_path, "r") as f:
        return yaml.safe_load(f)


STATS_CONFIG = _load_stats_config()


def build_strategy_config_dict(strategy_row: dict) -> dict:
    """
    Reassemble a metadata.strategy row back into the full config dict
    shape generate_signals() expects. Identical to simulator/main.py's
    version of this function.
    """
    config = dict(strategy_row["strategy_config"])
    config["strategy_name"] = strategy_row["strategy_name"]
    config["time_horizon"] = strategy_row["time_horizon"]
    config["take_profit"] = {
        "type": strategy_row["take_profit_type"],
        "value": float(strategy_row["take_profit_value"]),
    }
    config["stop_loss"] = {
        "type": strategy_row["stop_loss_type"],
        "value": float(strategy_row["stop_loss_value"]),
    }
    return config


def parse_start_date(start_date_str: str):
    """Same date formats as simulator/main.py's parse_simulator_start_date."""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(start_date_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"Unrecognized date format for start_date: {start_date_str!r}")


def build_resampled_signals(resampled_df, strategy_config_dict):
    """Identical to simulator/main.py's version -- runs the signal pipeline for one strategy."""
    indicator_df, condition_df, signal_series = generate_signals(resampled_df, config_dict=strategy_config_dict)
    combined = pd.concat([indicator_df, condition_df], axis=1)
    combined["signal"] = signal_series
    combined = combined.dropna().reset_index(drop=True)
    return combined[["datetime", "signal"]]


def _open_live_position(client, symbol, direction, candle, balance, config,
                         take_profit_pct, stop_loss_pct):
    """
    Place a real opening order on Bybit and build the position dict from
    its actual fill -- the live equivalent of simulator.py's
    _open_position(), but priced/sized off the real exchange fill instead
    of the candle's open price.

    quantity is still SIZED off the candle open (balance * position_size%
    / current price) since that's the best estimate available before the
    order exists -- but the position actually opened (entry_price,
    quantity, fee) reflects Bybit's real fill once placed.
    """
    estimate_price = float(candle["open"])
    target_quantity = _position_size(balance, config, estimate_price)

    order = place_market_order(client, symbol, "long" if direction == 1 else "short", target_quantity)

    entry_price = order["avg_price"]
    quantity = order["filled_qty"]
    take_profit, stop_loss = _tp_sl_prices(entry_price, direction, take_profit_pct, stop_loss_pct)

    return {
        "direction": "long" if direction == 1 else "short",
        "entry_time": candle["datetime"],
        "entry_price": round(entry_price, 4),
        "quantity": round(quantity, 4),
        "take_profit": round(float(take_profit), 4),
        "stop_loss": round(float(stop_loss), 4),
        "entry_fee": round(order["fee"], 4),
        "current_price": round(entry_price, 4),
        "unrealized_pnl": 0.0,
        "leaning": _leaning(entry_price, take_profit, stop_loss),
        "status": "open",
    }


def _close_live_position(client, symbol, position, exit_time, exit_reason, balance, config):
    """
    Place a real closing order on Bybit (opposite side of the open
    position) and build the closed-trade record from its actual fill --
    the live equivalent of simulator.py's _close_position(), but priced
    off the real exchange fill instead of a candle price.

    net_pnl = gross PnL from real entry/exit fill prices, minus the real
    entry + exit fees Bybit charged (no slippage estimate needed -- the
    fill price already IS whatever slippage happened).
    """
    direction = 1 if position["direction"] == "long" else -1
    quantity = position["quantity"]
    entry_price = position["entry_price"]

    # Closing order is the opposite side of however the position was opened.
    close_direction = "short" if position["direction"] == "long" else "long"
    order = place_market_order(client, symbol, close_direction, quantity)

    exit_price = order["avg_price"]
    exit_fee = order["fee"]

    if direction == 1:
        gross_pnl = (exit_price - entry_price) * quantity
    else:
        gross_pnl = (entry_price - exit_price) * quantity

    # entry_fee is only present if this position was opened AND closed
    # within the same run. If execution.main.py was restarted while this
    # position was open, execution.positions has no entry_fee column to
    # resume it from -- estimate it from config["commission"] instead of
    # silently treating it as zero (better an estimate than understating
    # real fees paid).
    entry_fee = position.get("entry_fee")
    if entry_fee is None:
        entry_fee = entry_price * quantity * (config.get("commission", 0.0) / 100)

    total_fee = entry_fee + exit_fee
    net_pnl = gross_pnl - total_fee
    new_balance = float(balance + net_pnl)

    trade = {
        "direction": position["direction"],
        "entry_date_time": position["entry_time"],
        "exit_date_time": exit_time,
        "entry_price": round(float(entry_price), 4),
        "exit_price": round(float(exit_price), 4),
        "quantity": round(float(quantity), 4),
        "gross_pnl": round(float(gross_pnl), 4),
        "commission": round(float(total_fee), 4),
        "slippage": 0.0,
        "net_pnl": round(float(net_pnl), 4),
        "exit_reason": exit_reason,
        "balance": round(new_balance, 4),
    }
    return trade, new_balance


def run_execution(client, exchange, symbol, config, strategy_name, time_horizon,
                   strategy_config_dict, take_profit_pct, stop_loss_pct):
    """
    Advance the live execution by however many new 1-minute candles are
    available from Bybit. Same signal/TP-SL/direction-change RULES as
    simulator/main.py's run_simulator(), but every open/close is a real
    Bybit order, and the ledger is built from that order's real fill
    (see _open_live_position/_close_live_position above) instead of the
    candle price the decision was triggered on.
    """
    allow_long = config.get("allow_long", True)
    allow_short = config.get("allow_short", True)

    conn = get_db_connection()
    try:
        state = get_execution_state(conn, exchange, symbol, strategy_name)
    finally:
        conn.close()

    if state is None:
        balance = config["initial_balance"]
        position = None
        last_processed = None
    else:
        balance = state["balance"]
        position = state["position"]
        last_processed = state["last_processed"]

    # Pull recent live candles straight from Bybit -- enough bars to cover
    # both the 1-minute walk-forward and the resample window the strategy's
    # time_horizon needs (e.g. 200 1-minute candles comfortably covers a
    # "3min" or "1h" resample warm-up).
    ohlcv_1m = get_live_ohlcv(client, symbol, limit=500)

    if last_processed is not None:
        ohlcv_1m = ohlcv_1m[ohlcv_1m["datetime"] > last_processed].reset_index(drop=True)

    if ohlcv_1m.empty:
        print(f"{exchange} {symbol} ({strategy_name}): no new candles.")
        return 0

    ohlcv_resampled = (
        ohlcv_1m.set_index("datetime")
        .resample(time_horizon)
        .agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"})
        .dropna()
        .reset_index()
    )

    if ohlcv_resampled.empty:
        signals = pd.DataFrame(columns=["datetime", "signal"])
    else:
        signals = build_resampled_signals(ohlcv_resampled, strategy_config_dict)

    # Same time-horizon gate as simulator/main.py: a signal only takes
    # effect on the 1-minute candle where a new resampled candle just closed.
    if not signals.empty:
        aligned = pd.merge_asof(
            ohlcv_1m[["datetime"]], signals, on="datetime", direction="backward"
        )
        aligned["signal"] = aligned["signal"].fillna(0)
        is_new_signal_bar = aligned["datetime"].isin(signals["datetime"])
        aligned.loc[~is_new_signal_bar, "signal"] = 0
    else:
        aligned = ohlcv_1m[["datetime"]].copy()
        aligned["signal"] = 0

    closed_trades = []
    last_candle_time = last_processed

    for i in range(len(ohlcv_1m)):
        candle = {
            "datetime": ohlcv_1m["datetime"].iloc[i].to_pydatetime(),
            "open": float(ohlcv_1m["open"].iloc[i]),
            "high": float(ohlcv_1m["high"].iloc[i]),
            "low": float(ohlcv_1m["low"].iloc[i]),
            "close": float(ohlcv_1m["close"].iloc[i]),
        }
        signal = int(aligned["signal"].iloc[i])
        closed_trade = None

        # Step: monitor open position (mark price / unrealized PnL / leaning) --
        # same math as simulator.step_candle(), no order involved.
        if position is not None:
            direction = 1 if position["direction"] == "long" else -1
            close_price = candle["close"]
            position["current_price"] = round(close_price, 4)
            if direction == 1:
                position["unrealized_pnl"] = round((close_price - position["entry_price"]) * position["quantity"], 4)
            else:
                position["unrealized_pnl"] = round((position["entry_price"] - close_price) * position["quantity"], 4)
            position["leaning"] = _leaning(close_price, position["take_profit"], position["stop_loss"])

            # TP/SL check against this candle's high/low -- same rule as
            # simulator. (The returned exit_price itself is unused here --
            # the real close order's own fill price is what actually gets
            # recorded -- only exit_reason matters, to know WHETHER and
            # WHY to close.)
            _, exit_reason = _check_exit(position, candle)

            # Direction-change rule: opposite-direction signal closes the
            # open position even if TP/SL wasn't hit. Same-direction signal
            # is a no-op -- existing trade keeps running untouched.
            if exit_reason is None and signal != 0:
                current_direction = 1 if position["direction"] == "long" else -1
                if signal == -current_direction:
                    exit_reason = "direction_change"
                else:
                    signal = 0

            if exit_reason is not None:
                # Real close order placed here -- ledger built from its
                # actual fill, not from exit_price/candle close.
                closed_trade, balance = _close_live_position(
                    client, symbol, position, candle["datetime"], exit_reason, balance, config
                )
                position = None
                # signal keeps its value so a direction-change can reopen
                # in the new direction on this same candle, below.

        # Step: open position (only if flat).
        if position is None and signal != 0:
            if signal == 1 and not allow_long:
                signal = 0
            if signal == -1 and not allow_short:
                signal = 0

            if signal != 0:
                # Real open order placed here -- position built from its
                # actual fill, not from candle open.
                position = _open_live_position(
                    client, symbol, signal, candle, balance, config, take_profit_pct, stop_loss_pct
                )

        if closed_trade is not None:
            closed_trade["cumulative_pnl"] = round(closed_trade["balance"] - config["initial_balance"], 4)
            closed_trades.append(closed_trade)

        last_candle_time = candle["datetime"]

    conn = get_db_connection()
    try:
        cumulative_pnl = round(balance - config["initial_balance"], 4)
        save_execution_state(conn, exchange, symbol, strategy_name, time_horizon, last_candle_time, round(balance, 4), position, cumulative_pnl)
        trade_ledger = pd.DataFrame(closed_trades)
        append_execution_trades(conn, exchange, symbol, strategy_name, trade_ledger)
    finally:
        conn.close()

    print(
        f"{exchange} {symbol} ({strategy_name}, {time_horizon}): processed {len(ohlcv_1m)} candle(s), "
        f"{len(closed_trades)} trade(s) closed, balance {balance:.2f}, "
        f"position {'open (' + position['direction'] + ')' if position else 'flat'}"
    )

    conn = get_db_connection()
    try:
        summary = get_execution_summary(conn, exchange, symbol, strategy_name)
    finally:
        conn.close()

    if summary is not None:
        wl = summary["win_loss"]
        print(
            f"    summary: {summary['total_trades']} total trade(s), "
            f"net PnL {summary['total_net_profit']:.2f}, "
            f"wins {wl['wins']} / losses {wl['losses']} "
            f"(win rate {wl['win_rate']:.1%})"
        )

    # Stats: one shared execution.stats table, one row per
    # exchange+symbol+strategy -- same pattern as simulator/main.py's
    # equivalent block, just computed from execution's own (real-money)
    # ledger via build_execution_equity_curve_from_ledger() instead of
    # simulator's paper one. Skipped if there are no closed trades yet:
    # quantstats' metrics need at least one return to be meaningful.
    if summary is not None and summary["total_trades"] > 0:
        conn = get_db_connection()
        try:
            equity_curve = build_execution_equity_curve_from_ledger(
                conn, exchange, symbol, strategy_name, config["initial_balance"]
            )
        finally:
            conn.close()

        if equity_curve is not None and len(equity_curve) > 1:
            stats_dict = compute_stats(
                {"equity_curve": equity_curve, "total_trades": summary["total_trades"]},
                STATS_CONFIG,
            )
            stats_row = dict(stats_dict["metrics"])
            stats_row["total_trades"] = summary["total_trades"]

            conn = get_db_connection()
            try:
                save_execution_stats(conn, exchange, symbol, strategy_name, time_horizon, stats_row)
            finally:
                conn.close()

    return len(ohlcv_1m)


if __name__ == "__main__":

    # Bybit credentials only -- BYBIT_API_KEY/BYBIT_API_SECRET/BYBIT_DEMO
    # in .env. Everything else (which pair, which strategy, execution
    # settings) is DB-driven, read below.
    client = get_client_from_env()

    # Universe: every (exchange, symbol) pair currently registered in
    # execution.config -- same DB-driven pattern as simulator/main.py's
    # get_simulator_universe(). Add a pair by calling
    # save_execution_config(); remove one by deleting its row.
    conn = get_db_connection()
    try:
        universe = get_execution_universe(conn)
    finally:
        conn.close()

    if not universe:
        raise RuntimeError(
            "No (exchange, symbol) pairs found in execution.config. "
            "Call save_execution_config() for at least one pair first."
        )

    print(f"Active execution universe: {universe}")

    for exchange, symbol in universe:
        conn = get_db_connection()
        try:
            config = get_execution_config(conn, exchange, symbol)
        finally:
            conn.close()

        if config is None:
            print(f"{exchange} {symbol}: no execution.config row -- skipping.")
            continue

        strategy_name = config["strategy_name"]

        metadata_conn = get_metadata_connection()
        try:
            strategy_rows = get_strategies(metadata_conn, exchange=exchange, coin=symbol)
        finally:
            metadata_conn.close()

        strategy_row = next((s for s in strategy_rows if s["strategy_name"] == strategy_name), None)

        if strategy_row is None:
            print(f"{exchange} {symbol}: strategy {strategy_name!r} not found in metadata.strategy -- skipping.")
            continue

        if not strategy_row.get("execution_enabled", True):
            print(f"{exchange} {symbol}: strategy {strategy_name!r} has execution_enabled = False -- skipping.")
            continue

        time_horizon = strategy_row["time_horizon"]
        strategy_config_dict = build_strategy_config_dict(strategy_row)
        take_profit_pct = float(strategy_row["take_profit_value"])
        stop_loss_pct = float(strategy_row["stop_loss_value"])

        run_execution(
            client, exchange, symbol, config, strategy_name, time_horizon,
            strategy_config_dict, take_profit_pct, stop_loss_pct
        )