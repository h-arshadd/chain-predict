"""
bybit_client.py
----------------
Thin wrapper around Bybit's REST API for the execution folder. Two jobs
only:

  1. get_live_ohlcv() -- pull recent 1-minute candles directly from
     Bybit (not the DB -- execution trades off live exchange data, not
     whatever's been backfilled into binance.*/bybit.* tables).
  2. place_market_order() -- send a real market order when a position
     opens or closes.

Uses pybit (Bybit's official Python SDK) since it already handles request
signing. Install with: pip install pybit

Symbol format: Bybit expects e.g. "BTCUSDT", not "btc" -- to_bybit_symbol()
does that conversion so the rest of execution/ can keep using the same
lowercase "btc" convention as simulator/backtest/signals.
"""

import os
from datetime import datetime, timezone

import pandas as pd
from dotenv import load_dotenv
from pybit.unified_trading import HTTP

load_dotenv()


def to_bybit_symbol(symbol: str) -> str:
    """'btc' -> 'BTCUSDT'. Execution is USDT-perpetual only for now."""
    return f"{symbol.upper()}USDT"


def get_client(api_key: str, api_secret: str, testnet: bool) -> HTTP:
    """Build a pybit HTTP session. Called once in main.py and reused."""
    return HTTP(api_key=api_key, api_secret=api_secret, testnet=testnet)


def get_client_from_env() -> HTTP:
    """
    Build a pybit HTTP session from BYBIT_API_KEY / BYBIT_API_SECRET /
    BYBIT_TESTNET in .env -- same pattern db_utils.get_db_connection() and
    metadata_utils.get_db_connection() already use for DB credentials.
    Secrets never go in execution/config.yaml or the DB -- .env only.

    BYBIT_TESTNET: "true"/"false" (case-insensitive), defaults to "true"
    so a missing/misconfigured .env fails safe onto testnet rather than
    accidentally trading live.
    """
    api_key = os.getenv("BYBIT_API_KEY")
    api_secret = os.getenv("BYBIT_API_SECRET")
    testnet = os.getenv("BYBIT_TESTNET", "true").strip().lower() != "false"

    if not api_key or not api_secret:
        raise RuntimeError(
            "BYBIT_API_KEY / BYBIT_API_SECRET not set in .env -- add them before running execution/main.py."
        )

    return get_client(api_key=api_key, api_secret=api_secret, testnet=testnet)


def get_live_ohlcv(client: HTTP, symbol: str, limit: int = 200) -> pd.DataFrame:
    """
    Fetch the most recent `limit` 1-minute candles for `symbol` from
    Bybit directly (category="linear" -- USDT perpetuals).

    Returns a DataFrame with columns: datetime, open, high, low, close,
    volume -- sorted oldest to newest, same shape/column names get_data()
    returns elsewhere in the pipeline (see data_downloader.get_data()),
    so build_resampled_signals() / step_candle() work unchanged.
    """
    bybit_symbol = to_bybit_symbol(symbol)
    response = client.get_kline(
        category="linear",
        symbol=bybit_symbol,
        interval="1",
        limit=limit,
    )
    rows = response["result"]["list"]

    df = pd.DataFrame(
        rows,
        columns=["start", "open", "high", "low", "close", "volume", "turnover"],
    )
    df["datetime"] = pd.to_datetime(df["start"].astype("int64"), unit="ms", utc=True).dt.tz_localize(None)
    for col in ("open", "high", "low", "close", "volume"):
        df[col] = df[col].astype(float)

    df = df[["datetime", "open", "high", "low", "close", "volume"]]
    df = df.sort_values("datetime").reset_index(drop=True)
    return df


def place_market_order(client: HTTP, symbol: str, direction: str, quantity: float) -> dict:
    """
    Send a real market order on Bybit.

    direction : "long" or "short" -- "long" opens/closes toward Buy,
        "short" opens/closes toward Sell. main.py calls this once to
        open a position and once to close it, same as it calls
        simulator.step_candle() for both -- the side passed in is
        whichever direction the trade needs at that moment (see main.py).
    quantity  : float -- order size in base currency (e.g. BTC amount),
        same "quantity" step_candle()/simulator.py already computes.

    Returns Bybit's raw order response dict. Raises if the API call
    itself errors (network/auth) -- main.py should not swallow that
    silently, since a failed order means the DB state and the real
    exchange position have gone out of sync.
    """
    bybit_symbol = to_bybit_symbol(symbol)
    side = "Buy" if direction == "long" else "Sell"

    return client.place_order(
        category="linear",
        symbol=bybit_symbol,
        side=side,
        orderType="Market",
        qty=str(round(quantity, 6)),
    )


def utcnow() -> datetime:
    """Plain UTC now, naive (matches how datetime columns are stored elsewhere)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)