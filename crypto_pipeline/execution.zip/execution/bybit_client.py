"""
bybit_client.py
----------------
Thin wrapper around Bybit's REST API for the execution folder. Jobs:

  1. get_live_ohlcv() -- pull recent 1-minute candles directly from
     Bybit (not the DB -- execution trades off live exchange data, not
     whatever's been backfilled into binance.*/bybit.* tables).
  2. place_market_order() -- send a real market order when a position
     opens or closes, then look up what it actually filled at
     (avgPrice / cumExecQty / cumExecFee) and return that -- a market
     order's ack response does NOT include fill data, only orderId, so
     the fill has to be fetched back separately right after placing.

Uses pybit (Bybit's official Python SDK) since it already handles request
signing. Install with: pip install pybit

Symbol format: Bybit expects e.g. "BTCUSDT", not "btc" -- to_bybit_symbol()
does that conversion so the rest of execution/ can keep using the same
lowercase "btc" convention as simulator/backtest/signals.
"""

import os
import time
from datetime import datetime, timezone
from decimal import Decimal, ROUND_DOWN

import pandas as pd
from dotenv import load_dotenv
from pybit.unified_trading import HTTP

load_dotenv()

# Cache of qtyStep per Bybit symbol, so we only hit get_instruments_info()
# once per symbol instead of on every single order.
_QTY_STEP_CACHE: dict[str, Decimal] = {}


def get_qty_step(client: HTTP, bybit_symbol: str) -> Decimal:
    """
    Bybit rejects any order qty that isn't an exact multiple of the
    instrument's qtyStep (ErrCode 10001 "Qty invalid") -- e.g. BTCUSDT
    linear has qtyStep "0.001", so 0.0149 is rejected but 0.014 or 0.015
    is accepted. Fetched live (not hardcoded) so this stays correct if a
    symbol's lot size ever changes or a new symbol is added.
    """
    if bybit_symbol not in _QTY_STEP_CACHE:
        info = client.get_instruments_info(category="linear", symbol=bybit_symbol)
        lot_filter = info["result"]["list"][0]["lotSizeFilter"]
        _QTY_STEP_CACHE[bybit_symbol] = Decimal(lot_filter["qtyStep"])
    return _QTY_STEP_CACHE[bybit_symbol]


def round_to_qty_step(quantity: float, qty_step: Decimal) -> str:
    """
    Round DOWN to the instrument's qtyStep, as Decimal to avoid float
    binary-representation drift (e.g. 0.0149 rendering as
    0.014900000000000001). Rounding down (not to nearest) guarantees we
    never send a qty larger than what was computed -- never risk
    over-ordering relative to the sized position.
    """
    step = Decimal(str(quantity)).quantize(qty_step, rounding=ROUND_DOWN)
    return str(step)


def to_bybit_symbol(symbol: str) -> str:
    """'btc' -> 'BTCUSDT'. Execution is USDT-perpetual only for now."""
    return f"{symbol.upper()}USDT"


def get_client(api_key: str, api_secret: str, demo: bool = False) -> HTTP:
    """
    Build a pybit HTTP session. Called once in main.py and reused.

    demo=True routes to Bybit's isolated Demo Trading sub-account
    (simulated balance, real production domain under the hood).
    demo=False is real production trading with real funds. Testnet
    support was removed entirely per team decision -- there is no
    testnet option here anymore, intentionally.
    """
    return HTTP(api_key=api_key, api_secret=api_secret, demo=demo)


def get_client_from_env() -> HTTP:
    """
    Build a pybit HTTP session from BYBIT_API_KEY / BYBIT_API_SECRET /
    BYBIT_DEMO in .env -- same pattern db_utils.get_db_connection() and
    metadata_utils.get_db_connection() already use for DB credentials.
    Secrets never go in execution/config.yaml or the DB -- .env only.

    Testnet has been removed entirely (per team decision) -- there are
    now only two environments, and each requires its OWN API key
    generated while your account is switched into that specific mode; a
    key from one will not work against the other:
      - demo       (BYBIT_DEMO=true):  api.bybit.com under the hood but
                     routed to an isolated demo sub-account with
                     simulated balance -- generate this key from the
                     Bybit website while your account is switched into
                     "Demo Trading" mode (hover the profile icon ->
                     Demo Trading), NOT from your regular API management
                     page. Note demo trading doesn't support every
                     endpoint production does (it's meant for practice,
                     not full parity).
      - production (BYBIT_DEMO=false or unset): api.bybit.com, REAL
                     funds, REAL orders.

    BYBIT_DEMO: "true"/"false" (case-insensitive), defaults to "false".
    If left unset, this connects to real production Bybit with real
    money -- there is no "fails safe" default anymore now that testnet
    is gone; make sure .env explicitly sets BYBIT_DEMO=true until you're
    actually ready for production.
    """
    api_key = os.getenv("BYBIT_API_KEY")
    api_secret = os.getenv("BYBIT_API_SECRET")
    demo = os.getenv("BYBIT_DEMO", "false").strip().lower() == "true"

    if not api_key or not api_secret:
        raise RuntimeError(
            "BYBIT_API_KEY / BYBIT_API_SECRET not set in .env -- add them before running execution/main.py."
        )

    return get_client(api_key=api_key, api_secret=api_secret, demo=demo)


def get_live_ohlcv(client: HTTP, symbol: str, limit: int = 200) -> pd.DataFrame:
    """
    Fetch the most recent `limit` 1-minute candles for `symbol` from
    Bybit directly (category="linear" -- USDT perpetuals).

    Returns a DataFrame with columns: datetime, open, high, low, close,
    volume -- sorted oldest to newest, same shape/column names get_data()
    returns elsewhere in the pipeline (see data_downloader.get_data()),
    so build_resampled_signals() works unchanged.
    """
    bybit_symbol = to_bybit_symbol(symbol)
    response = client.get_kline(
        category="linear",
        symbol=bybit_symbol,
        interval="1",
        limit=limit,
    )
    rows = response["result"]["list"]

    df = pd.DataFrame(
        rows,
        columns=["start", "open", "high", "low", "close", "volume", "turnover"],
    )
    df["datetime"] = pd.to_datetime(df["start"].astype("int64"), unit="ms", utc=True).dt.tz_localize(None)
    for col in ("open", "high", "low", "close", "volume"):
        df[col] = df[col].astype(float)

    df = df[["datetime", "open", "high", "low", "close", "volume"]]
    df = df.sort_values("datetime").reset_index(drop=True)
    return df


def _extract_fill(row: dict) -> dict:
    return {
        "avg_price": float(row["avgPrice"]),
        "filled_qty": float(row["cumExecQty"]),
        "fee": float(row["cumExecFee"]),
        "order_status": row["orderStatus"],
    }


def get_order_fill(client: HTTP, bybit_symbol: str, order_id: str,
                    max_attempts: int = 10, poll_seconds: float = 1.0) -> dict:
    """
    Look up what an order actually filled at. place_order()'s own response
    only echoes back orderId (no avgPrice/cumExecQty) -- the real fill has
    to be read back separately. Market orders fill almost immediately,
    but propagation to the history endpoints can lag by a second or two
    (more on demo trading, which doesn't have full endpoint parity with
    production) -- so this polls, and checks TWO endpoints each attempt:

      1. get_open_orders(openOnly=0) -- the "realtime" order endpoint.
         Despite the name, passing openOnly=0 also returns recently
         closed orders, and this endpoint updates faster than order
         history right after a fill.
      2. get_order_history() -- the historical endpoint, meant for
         orders that already fully settled. Slower to update, but used
         as a fallback each attempt in case the order already aged out
         of the realtime endpoint's short window.

    Returns dict: avg_price, filled_qty, fee (all float), order_status.
    Raises RuntimeError if the order can't be found or never gets filled
    within max_attempts.
    """
    bybit_symbol = to_bybit_symbol(bybit_symbol) if not bybit_symbol.endswith("USDT") else bybit_symbol

    for attempt in range(max_attempts):
        response = client.get_open_orders(
            category="linear",
            symbol=bybit_symbol,
            orderId=order_id,
            openOnly=0,
            limit=1,
        )
        rows = response["result"]["list"]

        if not rows:
            response = client.get_order_history(
                category="linear",
                symbol=bybit_symbol,
                orderId=order_id,
                limit=1,
            )
            rows = response["result"]["list"]

        if rows:
            row = rows[0]
            status = row["orderStatus"]
            if status == "Filled":
                return _extract_fill(row)
            if status in ("Cancelled", "Rejected"):
                raise RuntimeError(
                    f"Order {order_id} for {bybit_symbol} ended in status {status!r} -- not filled."
                )

        if attempt < max_attempts - 1:
            time.sleep(poll_seconds)

    raise RuntimeError(
        f"Order {order_id} for {bybit_symbol} did not reach 'Filled' status after "
        f"{max_attempts} attempt(s) (~{max_attempts * poll_seconds:.0f}s) -- check Bybit manually, "
        f"DB state was not updated. If this keeps happening on demo trading, confirm the order "
        f"actually filled on the Bybit website (Demo Trading -> Order History) -- demo accounts "
        f"don't support every endpoint with full parity to production."
    )


def place_market_order(client: HTTP, symbol: str, direction: str, quantity: float) -> dict:
    """
    Send a real market order on Bybit, then read back its actual fill.

    direction : "long" or "short" -- "long" opens/closes toward Buy,
        "short" opens/closes toward Sell. main.py calls this once to
        open a position and once to close it -- the side passed in is
        whichever direction the trade needs at that moment.
    quantity  : float -- desired order size in base currency (e.g. BTC
        amount), from the sizing math in simulator.py.

    Returns dict: order_id, side, avg_price, filled_qty, fee -- the REAL
    numbers Bybit filled at, not the requested quantity or any candle
    price. main.py must build the ledger from this dict, not from
    step_candle()'s paper-fill numbers, since a market order can fill at
    a different price/size than requested (slippage, partial fill).

    Raises if the API call itself errors (network/auth) or if the fill
    can't be confirmed -- main.py should not swallow that silently,
    since a failed/uncertain order means the DB state and the real
    exchange position may have gone out of sync.
    """
    bybit_symbol = to_bybit_symbol(symbol)
    side = "Buy" if direction == "long" else "Sell"

    qty_step = get_qty_step(client, bybit_symbol)
    qty_str = round_to_qty_step(quantity, qty_step)

    if Decimal(qty_str) <= 0:
        # position_size in execution.config produced a quantity smaller
        # than one qtyStep (e.g. BTCUSDT's 0.001) -- rounding down to
        # Bybit's lot size collapsed it to zero. Fail loudly: this means
        # execution.config's position_size is too small for current
        # price/leverage and needs to be raised.
        raise ValueError(
            f"Computed order qty {quantity} rounds down to {qty_str} for {bybit_symbol}, "
            f"below its qtyStep ({qty_step}). Increase position_size in execution.config."
        )

    order_response = client.place_order(
        category="linear",
        symbol=bybit_symbol,
        side=side,
        orderType="Market",
        qty=qty_str,
    )

    order_id = order_response["result"]["orderId"]
    fill = get_order_fill(client, bybit_symbol, order_id)

    return {
        "order_id": order_id,
        "side": side,
        "avg_price": fill["avg_price"],
        "filled_qty": fill["filled_qty"],
        "fee": fill["fee"],
    }


def utcnow() -> datetime:
    """Plain UTC now, naive (matches how datetime columns are stored elsewhere)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)