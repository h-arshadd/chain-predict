# crypto_pipeline/ml/timeseries/statsforecast_model.py

"""
statsforecast_model.py
------------------------
Auto-ARIMA (darts.models.StatsForecastAutoARIMA, backed by Nixtla's
`statsforecast` package) wrapper. Third timeseries regressor alongside
N-BEATS and TCN -- picked as the classical-statistics counterpart to
those two deep-learning models: no training epochs, fits an ARIMA order
automatically per-series via an information criterion, and is fast
enough to retrain at every step of historical_forecasts() (relevant for
fixed-window / walk-forward evaluation, PDF heading 10).

Unlike NBEATSModel/TCNModel (global, chunk-based, past_covariates
only), StatsForecastAutoARIMA is a LOCAL, univariate model -- it takes
NO input_chunk_length/output_chunk_length (Auto-ARIMA has no such
notion; n is only ever a predict()-time argument), and it supports
future_covariates instead of past_covariates (exogenous columns whose
values must be known/provided over the forecast horizon too, not just
up to "now" -- see base_timeseries_model.py's train()/predict()
docstrings for the past vs future covariate distinction). past_covariates
is accepted for interface consistency but ignored, with a warning.

Raw close price is used as the target series, same as nbeats_model.py/
tcn_model.py (see target_pipeline.py's timeseries branch).
"""

import logging
from typing import Optional

import numpy as np

from crypto_pipeline.ml.timeseries.base_timeseries_model import BaseTimeseriesModel, TimeSeries

try:
    from darts.models import StatsForecastAutoARIMA
    _import_error = None
except ImportError as _e:
    StatsForecastAutoARIMA = None
    # Keep the ORIGINAL exception instead of discarding it -- "darts is
    # required but not installed" is only one possible cause of this
    # import failing; it can just as easily be a missing/incompatible
    # sub-dependency (e.g. the `statsforecast` package itself, or a
    # version mismatch between it and this darts version) even when
    # darts itself imports fine elsewhere (proven by nbeats/tcn working
    # in the same run). Surfacing the real message is the only way to
    # tell those apart instead of guessing.
    _import_error = _e

logger = logging.getLogger(__name__)


class StatsForecastTimeseriesModel(BaseTimeseriesModel):
    """
    Args (forwarded to darts.models.StatsForecastAutoARIMA, which
    forwards them on to statsforecast.models.AutoARIMA):
        season_length: int -- seasonal period, e.g. 24 for hourly data
            with a daily seasonal pattern. Defaults to statsforecast's
            own default (1, no seasonality) if not given.
        Any other kwarg statsforecast.models.AutoARIMA accepts (e.g.
            max_p, max_q, max_d, stepwise).

    No input_chunk_length/output_chunk_length here -- unlike
    nbeats/tcn, Auto-ARIMA has no such concept. n (how many steps ahead
    to forecast) is only ever a predict()-time argument.
    """

    def train(
        self,
        target_series: "TimeSeries",
        past_covariates: Optional["TimeSeries"] = None,
        future_covariates: Optional["TimeSeries"] = None,
        val_series: Optional["TimeSeries"] = None,
        val_past_covariates: Optional["TimeSeries"] = None,
    ) -> "StatsForecastTimeseriesModel":
        if StatsForecastAutoARIMA is None:
            raise ImportError(
                "Failed to import darts.models.StatsForecastAutoARIMA. "
                f"Underlying error: {type(_import_error).__name__}: {_import_error}"
            ) from _import_error
        # val_series/val_past_covariates accepted for interface
        # consistency with BaseTimeseriesModel.train() (so
        # timeseries_pipeline.py can call every algorithm the same way)
        # but ignored here -- Auto-ARIMA is a classical statistical
        # model with no epochs/gradient training, so there's no
        # val_loss-driven early stopping for a validation set to feed.
        if val_series is not None:
            logger.warning(
                "StatsForecastTimeseriesModel does not use val_series "
                "(not an epoch-trained model) -- ignoring"
            )
        if past_covariates is not None:
            logger.warning(
                "StatsForecastTimeseriesModel does not support past_covariates "
                "(it's a future_covariates model) -- ignoring"
            )
        self.model = StatsForecastAutoARIMA(**self.hyperparams)
        self.model.fit(target_series, future_covariates=future_covariates)
        return self

    def predict(
        self,
        n: int,
        past_covariates: Optional["TimeSeries"] = None,
        future_covariates: Optional["TimeSeries"] = None,
    ) -> np.ndarray:
        self._require_trained()
        if past_covariates is not None:
            logger.warning(
                "StatsForecastTimeseriesModel does not support past_covariates "
                "(it's a future_covariates model) -- ignoring"
            )
        forecast = self.model.predict(n=n, future_covariates=future_covariates)
        return forecast.values().flatten()

    def _darts_model_class(self):
        return StatsForecastAutoARIMA