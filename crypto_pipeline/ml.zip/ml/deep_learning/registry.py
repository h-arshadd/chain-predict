# crypto_pipeline/ml/deep_learning/registry.py

"""
registry.py
-----------
Maps a config string (ml/config.yaml's model.algorithm) to a deep
learning model class. Same mechanism as ml/regressors/registry.py and
ml/classifiers/registry.py -- see those files' docstrings. A future
deep-learning pipeline never hardcodes "if algorithm == 'mlp'"
anywhere; it just calls build_dl_regressor(name, **params) or
build_dl_classifier(name, **params).

Only "mlp" lives here. lstm/gru used to be registered here too, but
with the flat (X, y) tables this pipeline hands every non-timeseries
model, they were fed exactly one timestep per row -- a sequence length
of 1 -- which makes an LSTM/GRU cell mathematically no different from
a linear layer. They captured no temporal information an MLP doesn't
already get, so keeping them here was misleading, not useful. Real
sequence modeling needs a lookback window of multiple past rows per
prediction; that's what ml/timeseries/rnn_model.py's LSTM/GRU (built
on darts.models.BlockRNNModel, same as nbeats/tcn) now provide instead
-- see that file's docstring for the full reasoning. Select them via
model_type: timeseries (ml/data_prep/config.yaml) and
ml/timeseries/registry.py's TS_MODELS, same as nbeats/tcn.

To add a new architecture here: write a new BaseRegressorNetwork /
BaseClassifierNetwork subclass under ml/deep_learning/, add one line
below, done. (For a sequence architecture, add it to
ml/timeseries/registry.py instead, following rnn_model.py's pattern.)
"""

from typing import Dict, Type

from crypto_pipeline.ml.deep_learning.base_network import BaseClassifierNetwork, BaseNetwork
from crypto_pipeline.ml.deep_learning.mlp import MLPClassifierModel, MLPRegressorModel

DL_REGRESSORS: Dict[str, Type[BaseNetwork]] = {
    "mlp": MLPRegressorModel,
}

DL_CLASSIFIERS: Dict[str, Type[BaseClassifierNetwork]] = {
    "mlp": MLPClassifierModel,
}


def build_dl_regressor(algorithm: str, **hyperparams) -> BaseNetwork:
    """
    Instantiate a deep learning regressor by config name.

    Args:
        algorithm: key into DL_REGRESSORS, e.g. "mlp"
        **hyperparams: forwarded to the model's constructor (hidden_layers,
            hidden_units, activation, dropout, batch_norm, optimizer,
            learning_rate, scheduler, scheduler_params, batch_size,
            epochs, early_stopping_patience, random_seed).

    Returns:
        An untrained BaseRegressorNetwork subclass instance (call .train() next).
    """
    if algorithm not in DL_REGRESSORS:
        raise ValueError(
            f"Unknown deep learning regression algorithm '{algorithm}'. "
            f"Available: {sorted(DL_REGRESSORS.keys())}. "
            f"(Looking for lstm/gru? They're timeseries-only now -- see "
            f"ml/timeseries/registry.py's TS_MODELS.)"
        )
    return DL_REGRESSORS[algorithm](**hyperparams)


def build_dl_classifier(algorithm: str, **hyperparams) -> BaseClassifierNetwork:
    """
    Instantiate a deep learning classifier by config name.

    Args:
        algorithm: key into DL_CLASSIFIERS, e.g. "mlp"
        **hyperparams: same set as build_dl_regressor().

    Returns:
        An untrained BaseClassifierNetwork subclass instance (call .train() next).
    """
    if algorithm not in DL_CLASSIFIERS:
        raise ValueError(
            f"Unknown deep learning classification algorithm '{algorithm}'. "
            f"Available: {sorted(DL_CLASSIFIERS.keys())}. "
            f"(Looking for lstm/gru? They're timeseries-only now -- see "
            f"ml/timeseries/registry.py's TS_MODELS.)"
        )
    return DL_CLASSIFIERS[algorithm](**hyperparams)