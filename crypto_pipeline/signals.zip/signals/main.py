"""
main.py
-------

Entry point of the Signal Module.
Orchestrates config loading, indicator calculation, and signal generation.
"""

from pathlib import Path
import yaml
import pandas as pd

from crypto_pipeline.signals.signal_helpers import calculate_indicators
from crypto_pipeline.signals.conditions import evaluate_conditions
from crypto_pipeline.signals.rules import apply_rules


def load_config(config_path=None) -> dict:
    """Load config from YAML file."""
    if config_path is None:
        config_path = Path(__file__).parent / "config.yaml"
    
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def split_config(config: dict) -> tuple:
    """Split config into indicator_config and strategy_config."""
    indicator_config = {k: v for k, v in config.items() if k != "strategy"}
    strategy_config = config["strategy"]
    return indicator_config, strategy_config


def generate_signals(df: pd.DataFrame, indicator_config: dict = None, strategy_config: dict = None) -> pd.Series:
    """
    Generate trading signals from OHLCV data.
    
    If configs not provided, loads from config.yaml automatically.
    Can also override by passing custom configs.
    
    Parameters
    ----------
    df : pd.DataFrame
        OHLCV data
    indicator_config : dict, optional
        Indicator configuration. If None, loads from config.yaml
    strategy_config : dict, optional
        Strategy configuration. If None, loads from config.yaml
    
    Returns
    -------
    pd.Series
        Trading signals (1=Buy, 0=Hold, -1=Sell)
    """
    # Load config if not provided
    if indicator_config is None or strategy_config is None:
        config = load_config()
        ind_cfg, strat_cfg = split_config(config)
        indicator_config = indicator_config or ind_cfg
        strategy_config = strategy_config or strat_cfg
    
    # Calculate indicators and assign aliases
    indicator_df = calculate_indicators(df, indicator_config)
    
    # Evaluate all strategy conditions
    condition_df = evaluate_conditions(indicator_df, strategy_config)
    
    # Combine conditions into final signals
    signals = apply_rules(condition_df, strategy_config)
    
    return signals


# ==========================================================
# Entry Point (config loading and orchestration only)
# ==========================================================

if __name__ == "__main__":

    from crypto_pipeline.data.data_downloader import get_data
    from datetime import datetime
    import os

    config = load_config()
    indicator_config, strategy_config = split_config(config)

    exchanges = ["binance", "bybit"]
    symbols = ["doge", "sol", "btc", "eth", "ada", "ltc", "mina", "sui"]

    # Create output folder
    output_dir = "signal_outputs"
    os.makedirs(output_dir, exist_ok=True)

    for exchange in exchanges:
        for symbol in symbols:

            result = get_data(
                exchange=exchange,
                symbol=symbol,
                start_date=datetime(2026, 6, 20, 0, 0, 0),
                end_date="now",
            )

            df = result["resampled"]

            # Calculate indicators
            indicator_df = calculate_indicators(df, indicator_config)
            
            # Evaluate conditions
            condition_df = evaluate_conditions(indicator_df, strategy_config)
            
            # Generate signals
            signals = apply_rules(condition_df, strategy_config)

            # Build comprehensive output
            output = pd.DataFrame({
                "datetime": df["datetime"],
                "open": df["open"],
                "high": df["high"],
                "low": df["low"],
                "close": df["close"],
                "volume": df["volume"],
                "ind_sma_20": indicator_df["ind_sma_20"],
            })
            
            # Add all conditions
            for col in condition_df.columns:
                output[col] = condition_df[col]
            
            # Add signal
            output["signal"] = signals

            # Save to CSV in output folder
            csv_filename = os.path.join(output_dir, f"{exchange}_{symbol}_signals.csv")
            output.to_csv(csv_filename, index=False)